package com.brain_mentors.views;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.Panel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.JToggleButton;
import java.awt.FlowLayout;

import com.brain_mentors.dao.UserDAO;
import com.brain_mentors.dto.UserDTO;


class userscreen extends JFrame{
	private JTextField txtUserid;
	private JTextField txtPassword;
	private JTextField txtUserid_1;
	private JTextField txtPassword_1;
	private JPasswordField passwordfield;
	private JTextField textfield_org;
	private JButton btnRegister;
	static  int counter;

	UserDAO userDAO=new UserDAO();
	private void doLogin(){
	String userid=textfield_org.getText();
			char []password=passwordfield.getPassword();
			UserDTO userDTO=new UserDTO(userid,password);

	try{
	if(userDAO.isLogin(userDTO)) {
		JOptionPane.showMessageDialog(this,"Welcome"+ userid);
		Dashboard dashboard=new Dashboard("Welcome"+ userid);
		dashboard.setVisible(true);
		
	}
	else
		JOptionPane.showMessageDialog(this,"Invalid"+ userid);
	
	}catch(SQLException ex){
	ex.printStackTrace();
	}catch(ClassNotFoundException ex){
	ex.printStackTrace();
	}catch(Exception ex){
	ex.printStackTrace();
	}
	}

	private void register(){
		String userid=textfield_org.getText();
		char []password=passwordfield.getPassword();
		//UserDAO userDAO=new UserDAO();
		UserDTO userDTO=new UserDTO(userid,password);
			try {
					int result=userDAO.add(userDTO);
					if(result>0) {
						JOptionPane.showMessageDialog(this, "Registered Successfully");}
					else
						JOptionPane.showMessageDialog(this, "Not Registered");
			}
			catch(ClassNotFoundException |SQLException ex) {
				System.out.print("DB Issue....");
				ex.printStackTrace();
			}
			catch(Exception ex) {
				System.out.print("Generic Issue....");
				ex.printStackTrace();
			}
		System.out.println("userid"+userid+"Password"+password+" "+password.toString());
		}



	public userscreen() {
		getContentPane().setFont(new Font("Arial Black", Font.BOLD, 15));
		setSize(500,500);
		setResizable(false);
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(228, 29, 100, 30);
		getContentPane().add(panel_1);
		panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel = new JLabel(" Login Page");
		panel_1.add(lblNewLabel);
		
		txtUserid_1 = new JTextField();
		txtUserid_1.setBounds(168, 174, 80, 30);
		txtUserid_1.setHorizontalAlignment(SwingConstants.CENTER);
		txtUserid_1.setFont(new Font("Arial", Font.BOLD, 12));
		txtUserid_1.setForeground(new Color(0, 0, 0));
		txtUserid_1.setText("UserId:");
		getContentPane().add(txtUserid_1);
		txtUserid_1.setColumns(10);
		
		txtPassword_1 = new JTextField();
		txtPassword_1.setBounds(168, 227, 80, 25);
		txtPassword_1.setFont(new Font("Arial", Font.BOLD, 12));
		txtPassword_1.setHorizontalAlignment(SwingConstants.CENTER);
		txtPassword_1.setText("Password:");
		txtPassword_1.setColumns(10);
		getContentPane().add(txtPassword_1);
		
		passwordfield = new JPasswordField();
		passwordfield.setBounds(273, 227, 80, 25);
		getContentPane().add(passwordfield);
		passwordfield.setColumns(10);
		
		textfield_org = new JTextField();
		textfield_org.setBounds(273, 176, 80, 25);
		textfield_org.setColumns(10);
		getContentPane().add(textfield_org);
		
		JButton btnNewButton = new JButton("Login");
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doLogin();

//				//				System.out.println(counter);
//				lblNewLabel.setText("Count"+counter);

			}
		});
		btnNewButton.setBounds(136, 309, 100, 25);
		getContentPane().add(btnNewButton);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("hello");
		
		Panel panel2 = new Panel();
		panel2.setBounds(0, 0, 0, 0);
		getContentPane().add(panel2);
		
		txtUserid = new JTextField();
		txtUserid.setBounds(0, 0, 0, 0);
		txtUserid.setText("UserId:");
		getContentPane().add(txtUserid);
		txtUserid.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(0, 0, 0, 0);
		txtPassword.setText("Password:");
		getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				register();
			}
		});
		btnRegister.setBounds(268, 309, 100, 25);
		getContentPane().add(btnRegister);
		setLocationRelativeTo(null);

		setVisible(true);
	}
	public static void main(String arg[]) {
		userscreen window=new userscreen();
	}
}