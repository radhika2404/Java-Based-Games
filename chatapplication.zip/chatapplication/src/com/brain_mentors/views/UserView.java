package com.brain_mentors.views;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class UserView extends JFrame{
public UserView(){


setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setSize(700,700); //width,height
setResizable(false);
setTitle("Login");
setLocation(40,40);// place loc
setLocationRelativeTo(null);

JLabel welcome=new JLabel("Login");
welcome.setFont(new Font("Arial",Font.BOLD,40));
Container container=this.getContentPane();
container.setLayout(null);
welcome.setBounds(100,100,200,200);
container.add(welcome);

JButton button=new JButton("Count");
button.addActionListener(new ActionListener(){
	int counter=0;
@Override 
public void actionPerformed(ActionEvent event){
counter++;
welcome.setText("Count"+counter);
} 
});
button.setBounds(100,300,200,50);


setVisible(true);

}

public static void main(String args[]) {
	
UserView userView=new UserView();
}

}



