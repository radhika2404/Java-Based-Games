package com.brain_mentors.network;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

import javax.swing.JTextArea;

import java.net.Socket;
import java.net.UnknownHostException;

import com.brain_mentor.utils.ConfigReader;

public class Client {
Socket socket;
OutputStream out;
InputStream in;
ClientWorker worker;
JTextArea textArea;


public Client(JTextArea textArea) throws UnknownHostException, IOException{
int PORT=Integer.parseInt(ConfigReader.getValue("PORTNO"));

socket=new Socket(ConfigReader.getValue("SERVER_IP"),PORT);
System.out.println("Bug1");
out=socket.getOutputStream();
in=socket.getInputStream();
this.textArea=textArea;
readMessages();
//System.out.println("Client comes");
//System.out.println("Enter the message send to the server");
//Scanner scanner=new Scanner(System.in);
//String message=scanner.nextLine();
//OutputStream out=socket.getOutputStream();
//out.write(message.getBytes());
//out.close();
//scanner.close();
//socket.close();
}
public void sendMessages(String message) throws IOException{
	message=message+"\n";
	out.write(message.getBytes());
}

public void readMessages() {
	worker=new ClientWorker(in,textArea);
	worker.start();
}

}
