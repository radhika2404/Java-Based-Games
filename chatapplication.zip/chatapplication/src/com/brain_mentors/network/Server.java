
package com.brain_mentors.network;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import com.brain_mentor.utils.ConfigReader;

public class Server{
ServerSocket serverSocket;
ArrayList<ServerWorker> worker=new ArrayList<>();
public Server() throws IOException{
int PORT=Integer.parseInt(ConfigReader.getValue("PORTNO"));
serverSocket=new ServerSocket(PORT);
System.out.println("Server Start");
handleClientRequest();
}
public void handleClientRequest() throws IOException{
	while(true) {
		Socket clientSocket=serverSocket.accept();
		ServerWorker serverWorker=new ServerWorker(clientSocket);
		worker.add(serverWorker);
		serverWorker.start();}
}

/*
public Server() throws IOException{
int PORT=Integer.parseInt(ConfigReader.getValue("PORTNO"));
serverSocket=new ServerSocket(PORT);
System.out.println("Server Start");
System.out.println("Waiting for client");
Socket socket=serverSocket.accept();
System.out.println("Client comes");
System.out.println("Client joins the server");
InputStream in=socket.getInputStream();
byte arr[]=in.readAllBytes();
String str=new String(arr);
System.out.println("Message rec from the client"+str);
in.close();

socket.close();
}*/

public static void main(String[] args) throws UnknownHostException, IOException{
	Server cl=new Server();
}
}
