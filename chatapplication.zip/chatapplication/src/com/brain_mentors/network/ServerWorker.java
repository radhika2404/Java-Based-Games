
package com.brain_mentors.network;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.io.BufferedReader;

//Thread==worker
//Worker need a job to perform
//for job u give runnable
//once job is created 
public class ServerWorker extends Thread {
private Socket clientSocket;
private InputStream in;
private OutputStream out;
private Server server;

public ServerWorker(Socket clientSocket) throws IOException{
this.clientSocket=clientSocket;
in=clientSocket.getInputStream();
out=clientSocket.getOutputStream();
System.out.println("New Client Comes");

}

@Override 
public void run(){
BufferedReader br=new BufferedReader(new InputStreamReader(in));
String line;

try{
while(true){
line=br.readLine();
if(line.equalsIgnoreCase("quit"))
break;
for(ServerWorker serverWorker:server.worker){
	line=line+"\n";
serverWorker.out.write(line.getBytes());
}
}
}catch(IOException e){
e.printStackTrace();
}finally{
try{
if(br!=null)
{
br.close();
}
if(in!=null){
in.close();}
if(out!=null){
out.close();}
if(clientSocket!=null){
clientSocket.close();}
}catch(Exception ex){
ex.printStackTrace();
}
}

}
}