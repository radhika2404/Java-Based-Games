package com.brain_mentors.dto;

public class UserDTO {
	private String userid;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	private char[] password;
	public char[] getPassword() {
		return password;
	}
	public void setPassword(char[] password) {
		this.password = password;
	}
	public UserDTO(String userid,char[] password){
	this.userid=userid;
	this.password=password;

	}
}
