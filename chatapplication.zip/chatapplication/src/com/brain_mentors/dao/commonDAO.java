package com.brain_mentors.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import static com.brain_mentor.utils.ConfigReader.getValue;

public interface commonDAO {
	public static Connection createConnection() throws ClassNotFoundException,SQLException{

	//1. Step-Load a driver
	Class.forName(getValue("DRIVER"));             //class is loaded at runtime.
	

	//2-Making a connection
	final String CONNECTION_STRING=getValue("CONNECTION_URL");
	final String USER_ID=getValue("USER_ID");
	final String PASSWORD=getValue("PASSWORD");
	Connection con=DriverManager.getConnection(CONNECTION_STRING,USER_ID,PASSWORD);
	if(con!=null)
	System.out.println("Connection created...");
	//con.close();
	return con;

}

	

}
